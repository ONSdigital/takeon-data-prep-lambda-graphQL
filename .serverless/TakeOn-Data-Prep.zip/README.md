# takeon-data-prep-lambda-graphQL
