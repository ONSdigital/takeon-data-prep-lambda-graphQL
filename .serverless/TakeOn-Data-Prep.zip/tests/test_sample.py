def test_sample():
    assert "First Python test" == "First Python test"
